# inventory_taker
Uses Aruco tags to take inventory of a fictional business
